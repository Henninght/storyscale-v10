# Storyscale

AI-powered LinkedIn content creation platform.

## Quick Start

```bash
npm install
npm run dev
```

Updated: October 1, 2025
